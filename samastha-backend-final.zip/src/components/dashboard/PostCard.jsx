'use client';

import { useState, useEffect, useRef } from 'react';
import Image from 'next/image';

const getTimeAgo = (date) => {
  if (!date) return "Centenary";

  const now = new Date();
  const created = new Date(date);
  const diffInSeconds = Math.floor((now - created) / 1000);

  if (diffInSeconds < 60) return "Just now";
  const diffInMinutes = Math.floor(diffInSeconds / 60);
  if (diffInMinutes < 60) return `${diffInMinutes}m ago`;
  const diffInHours = Math.floor(diffInMinutes / 60);
  if (diffInHours < 24) return `${diffInHours}h ago`;
  const diffInDays = Math.floor(diffInHours / 24);
  if (diffInDays === 1) return "Yesterday";

  return created.toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" });
};

const PostCard = ({ caption, thumbnail, postId, createdAt, naseehath }) => {
  const [imageDimensions, setImageDimensions] = useState(null);
  const [isLoading, setIsLoading] = useState(false);
  const [isModalVisible, setIsModalVisible] = useState(false);
  const [currentImageIndex, setCurrentImageIndex] = useState(0);
  const [expanded, setExpanded] = useState(false);
  const [timeAgo, setTimeAgo] = useState(getTimeAgo(createdAt));
  const [imageLoadError, setImageLoadError] = useState(false); // Track image load errors

  const isLogged = false;

  useEffect(() => {
    const interval = setInterval(() => {
      setTimeAgo(getTimeAgo(createdAt));
    }, 60000);

    return () => clearInterval(interval);
  }, [createdAt]);

  useEffect(() => {
    if (thumbnail && thumbnail.length > 0 && thumbnail[0]) {
      console.log(`Loading image for post ${postId}:`, thumbnail[0]); // Debug log
      const img = new window.Image();
      img.src = thumbnail[0];
      img.onload = () => {
        console.log(`Image loaded successfully for post ${postId}:`, { width: img.width, height: img.height });
        setImageDimensions({ width: img.width, height: img.height });
      };
      img.onerror = () => {
        console.error(`Failed to load image for post ${postId}:`, thumbnail[0]);
        setImageLoadError(true);
        // Fallback dimensions if image fails to load
        setImageDimensions({ width: 640, height: 360 }); // Default 16:9 aspect ratio
      };
    } else {
      console.log(`No thumbnail for post ${postId}, treating as text-only`);
    }
  }, [thumbnail, postId]);

  const handleShare = async () => {
    if (navigator.share) {
      try {
        await navigator.share({
          title: 'Share Post',
          text: `${caption} @Sargalayam App`,
          url: thumbnail[currentImageIndex],
        });
        console.log("Shared successfully!");
      } catch (error) {
        console.error("Error sharing:", error);
        alert("Failed to share post.");
      }
    } else {
      alert("Sharing is not supported on this browser.");
    }
  };

  const download = async () => {
    setIsLoading(true);
    const activeImage = thumbnail[currentImageIndex];
    const filename = `sargalayam_${new Date().getTime()}.jpg`;

    try {
      const response = await fetch(activeImage);
      const blob = await response.blob();
      const url = window.URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = filename;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      window.URL.revokeObjectURL(url);
      alert("Image downloaded successfully!");
    } catch (error) {
      console.error("Error downloading file:", error);
      alert("Failed to download image.");
    } finally {
      setIsLoading(false);
    }
  };

  const handleReadMoreToggle = () => {
    setExpanded(!expanded);
  };

  // Always render text-only posts or if there's an image load error
  const shouldRenderContent = naseehath === "textonly" || imageDimensions || imageLoadError;

  if (!shouldRenderContent) {
    return (
      <div className="flex flex-col items-center px-4 mb-14 border border-white pt-4 rounded-lg bg-gray-50">
        <div className="flex flex-row gap-3 items-start justify-center border border-gray-200 py-1 px-2 rounded-lg bg-gray-50 mb-4 w-full">
          <div className="flex justify-center items-center flex-row flex-1">
            <Image
              src="/images/logo.png"
              alt="Logo"
              width={40}
              height={40}
              className="rounded-full"
            />
            <div className="flex justify-center flex-1 ml-3 gap-y-1">
              <p className="font-semibold text-sm line-clamp-1">SAMASTHA</p>
              <p className="text-xs text-gray-900 line-clamp-1">Centenary</p>
            </div>
          </div>
          <div className="flex flex-row gap-2">
            <button onClick={download} disabled className="p-3 rounded-full">
              <svg className="w-5 h-5 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1M16 12l-4 4m0 0l-4-4m4 4V3" />
              </svg>
            </button>
            <button onClick={handleShare} disabled className="p-3 rounded-full">
              <svg className="w-5 h-5 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8.684 13.342C8.886 12.938 9 12.482 9 12c0-.482-.114-.938-.316-1.342m0 2.684a3 3 0 110-2.684m0 2.684l6.632 3.316m-6.632-6l6.632-3.316m0 0a3 3 0 105.367-2.684 3 3 0 00-5.367 2.684zm0 9.316a3 3 0 105.367 2.684 3 3 0 00-5.367-2.684z" />
              </svg>
            </button>
          </div>
        </div>
        <div className="w-full h-48 bg-gray-200 rounded-lg flex items-center justify-center">
          <p>Loading...</p>
        </div>
      </div>
    );
  }

  const screenWidth = 640;
  const paddingHorizontal = 16;
  const adjustedWidth = screenWidth - paddingHorizontal;
  const aspectRatio = imageDimensions ? imageDimensions.width / imageDimensions.height : 1;
  const normalHeight = adjustedWidth / aspectRatio;

  return (
    <div className="flex flex-col items-center px-4 mb-8 border border-white pt-4 rounded-lg bg-gray-50">
      <div className="flex flex-row gap-3 items-start justify-center border border-gray-200 py-1 px-2 rounded-lg bg-gray-50 w-full">
        <div className="flex justify-center items-center flex-row flex-1">
          <Image
            src="/images/logo.png"
            alt="Logo"
            width={40}
            height={40}
            className="rounded-full"
          />
          <div className="flex justify-center flex-1 ml-3 gap-y-1">
            <p className="font-semibold text-sm line-clamp-1">
              {naseehath === "naseehath" ? "Daily Naseehath" : "SAMASTHA"}
            </p>
            <p className="text-xs text-gray-900 line-clamp-1">{timeAgo}</p>
          </div>
        </div>
        <div className="flex flex-row gap-2">
          <button onClick={download} className="p-3 rounded-full">
            <svg className="w-5 h-5 text-gray-700" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1M16 12l-4 4m0 0l-4-4m4 4V3" />
            </svg>
          </button>
          <button onClick={handleShare} className="p-3 rounded-full">
            <svg className="w-5 h-5 text-gray-700" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8.684 13.342C8.886 12.938 9 12.482 9 12c0-.482-.114-.938-.316-1.342m0 2.684a3 3 0 110-2.684m0 2.684l6.632 3.316m-6.632-6l6.632-3.316m0 0a3 3 0 105.367-2.684 3 3 0 00-5.367 2.684zm0 9.316a3 3 0 105.367 2.684 3 3 0 00-5.367-2.684z" />
            </svg>
          </button>
        </div>
      </div>

      <div className="mt-4 w-full relative rounded-lg overflow-hidden">
        {naseehath === "textonly" ? (
          <p className="text-4xl font-medium text-justify">{caption}</p>
        ) : (
          <img
            src={thumbnail[currentImageIndex]}
            alt="Post"
            style={{ width: adjustedWidth, height: normalHeight }}
            className="rounded-lg object-cover"
            onError={() => {
              console.error(`Image display failed for post ${postId}:`, thumbnail[currentImageIndex]);
              setImageLoadError(true);
            }}
          />
        )}

        {!isLogged && !naseehath && (
          <button
            className="absolute right-4 bottom-4 bg-gray-400 p-2 rounded-full opacity-40"
            disabled
          >
            <svg className="w-6 h-6 text-black" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 12h6m-3-3v6M9 12H3m3-3v6" />
            </svg>
          </button>
        )}
      </div>

      {isLoading && (
        <div className="absolute inset-0 flex items-center justify-center z-50">
          <svg className="animate-spin h-8 w-8 text-blue-500" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
            <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
            <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" />
          </svg>
        </div>
      )}

      {caption && (
        <div className="flex flex-col w-full mt-3">
          <p className={`text-base font-light ${!expanded ? 'line-clamp-2' : ''}`}>
            {caption}
          </p>
          {caption.length > 100 && (
            <button onClick={handleReadMoreToggle} className="text-blue-500 mt-1 text-left">
              {expanded ? 'Read Less' : 'Read More'}
            </button>
          )}
        </div>
      )}
    </div>
  );
};

export default PostCard;