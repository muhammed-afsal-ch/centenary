'use server'; // Indicates this is a server-side route

export async function POST(req) {
  const apiUrl = process.env.NEXT_PUBLIC_API_URL || 'https://samastha100.skssf.in:3001';
  const apiKey = process.env.SECRET_KEY || 'your-api-pass';

  console.log('API URL:', apiUrl);
  console.log('API Key:', apiKey);

  try {
    // Parse the incoming request body (JSON)
    const { postId } = await req.json();

    if (!postId) {
      return new Response(JSON.stringify({ error: 'Post ID is required' }), {
        status: 400,
        headers: { 'Content-Type': 'application/json' },
      });
    }

    // Ensure a trailing slash in apiUrl and construct the full URL
    const baseUrl = apiUrl.endsWith('/') ? apiUrl : `${apiUrl}/`;
    const fullUrl = `${baseUrl}api/posts/delete`;
    console.log('Constructed URL:', fullUrl);

    // Set up a timeout for the fetch request (60 seconds)
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 60000);

    // Forward the request to the external API
    const response = await fetch(fullUrl, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-api-key': apiKey,
      },
      body: JSON.stringify({ postId }),
      signal: controller.signal,
    });

    // Log response status and headers
    console.log('Response Status:', response.status);
    console.log('Response Headers:', response.headers);

    clearTimeout(timeoutId);

    const contentType = response.headers.get('content-type');
    if (!contentType || !contentType.includes('application/json')) {
      throw new Error('Server did not return JSON');
    }

    const data = await response.json();

    if (!response.ok) {
      throw new Error(data.error || 'Failed to delete post');
    }

    return new Response(JSON.stringify({ message: 'Post deleted successfully!', ...data }), {
      status: 200,
      headers: { 'Content-Type': 'application/json' },
    });
  } catch (error) {
    console.error('Error in deletepost API:', error);
    let errorMessage = 'Failed to delete post';
    if (error.name === 'AbortError') {
      errorMessage = 'Request timed out after 60 seconds. The external API may be down or unreachable.';
    } else if (error.cause?.code === 'UND_ERR_CONNECT_TIMEOUT') {
      errorMessage = 'Connection timeout. Unable to reach the external API.';
    } else if (error.code === 'ERR_INVALID_URL') {
      errorMessage = 'Invalid URL for the external API. Please check NEXT_PUBLIC_API_URL.';
    }
    return new Response(JSON.stringify({ error: errorMessage }), {
      status: 500,
      headers: { 'Content-Type': 'application/json' },
    });
  }
}